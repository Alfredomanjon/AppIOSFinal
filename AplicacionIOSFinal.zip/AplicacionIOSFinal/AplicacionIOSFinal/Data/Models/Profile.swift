//
//  Profile.swift
//  AplicacionIOSFinal
//
//  Created by Alfredo Manjon on 04/06/2019.
//  Copyright © 2019 Alfredo Manjon. All rights reserved.
//

import Foundation

//Class Profile
class Profile: CustomStringConvertible {
    
    var photoProfile : String?
    var name : String?
    var surname : String?
    var mail : String?
    var phone : String?
    var address : String?
    var job : String?
    var type : PassengerType?
    
    //Constructor
    convenience init(photoProfile : String? = nil, name : String? = nil, surname : String? = nil, mail : String? = nil, phone : String? = nil, address : String? = nil,job : String? = nil, type : PassengerType? = nil){
        
        self.init()
        self.photoProfile = photoProfile
        self.name = name
        self.surname = surname
        self.mail = mail
        self.phone = phone
        self.address = address
        self.type = type
    }
    
    public var description: String{
        
        return """
        Passenger:
        photo: \(String(describing: photoProfile))
        name: \(String(describing: name))
        surname: \(String(describing: surname))
        phone: \(String(describing: phone))
        address: \(String(describing: address))
        job: \(String(describing: job))
        email: \(String(describing: mail))
        type: \(String(describing: type))
        """
    }
    
    
}
