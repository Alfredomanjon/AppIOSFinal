//
//  Train.swift
//  AplicacionIOSFinal
//
//  Created by Alfredo Manjon on 16/05/2019.
//  Copyright © 2019 Alfredo Manjon. All rights reserved.
//

import Foundation

// Class Train

class Train: CustomStringConvertible {
    
    var photo : String?
    var series : String?
    var capacity : String?
    var type : TrainType?
    var descripcion : String?
    
    convenience init (photo: String? = nil, series: String? = nil, capacity: String? = nil, type: TrainType? = nil, descripcion: String? = nil){
        self.init()
        self.photo = photo
        self.series = series
        self.capacity = capacity
        self.type = type
        self.descripcion = descripcion
    }
    
    public var description: String{
        
        return """
        Train:
        photo: \(String(describing: photo))
        series: \(String(describing: series))
        capacity: \(String(describing: capacity))
        type: \(String(describing: type))
        descripcion: \(String(describing: descripcion))

        """
        
    }
    
    
}
