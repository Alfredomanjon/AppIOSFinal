//
//  Travels.swift
//  AplicacionIOSFinal
//
//  Created by Alfredo Manjon on 28/05/2019.
//  Copyright © 2019 Alfredo Manjon. All rights reserved.
//

import Foundation

// class Travels

class Travels: CustomStringConvertible {
    
    var photoDestination : String?
    var destination : String?
    var departure : String?
    var km : String?
    var type : TravelType?
    var train : [Train]?
    var passengers : [Passenger]?
    
    convenience init (photoDestination: String? = nil, destination: String? = nil, departure: String? = nil, type: TravelType? = nil , km: String? = nil, train : [Train]? = nil, passengers : [Passenger]? = nil){
        self.init()
        self.photoDestination = photoDestination
        self.destination = destination
        self.departure = departure
        self.type = type
        self.km = km
        self.train = train
        self.passengers = passengers
    }
    
    public var description: String{
        
        return """
        Genral Information:
        photoDestination: \(String(describing: photoDestination))
        destination: \(String(describing: destination))
        departure: \(String(describing: departure))
        type: \(String(describing: type))
        train: \(String(describing: train))
        passengers: \(String(describing: passengers))
        """
        
    }
    
    
}
