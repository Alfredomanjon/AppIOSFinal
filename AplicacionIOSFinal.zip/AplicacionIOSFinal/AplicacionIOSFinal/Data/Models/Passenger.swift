//
//  Passengers.swift
//  AplicacionIOSFinal
//
//  Created by Alfredo Manjon on 09/05/2019.
//  Copyright © 2019 Alfredo Manjon. All rights reserved.
//

import Foundation

//Class Passenger
class Passenger: CustomStringConvertible {
    
    var photo: String?
    var name: String?
    var surname: String?
    var phone: String?
    var address: String?
    var email: String?
    var type: PassengerType?
    var photoType : String?
    //Constructor
    convenience init(photo: String? = nil,name: String? = nil, surname: String? = nil, phone: String? = nil, address: String? = nil, email:String? = nil,type: PassengerType? = nil , photoType: String?){
        
        self.init()
        self.photo = photo
        self.name = name
        self.surname = surname
        self.phone = phone
        self.address = address
        self.email = email
        self.type = type
        self.photoType = photoType
        
    }
    public var description: String{
        
        return """
        Passenger:
        photo: \(String(describing: photo))
        name: \(String(describing: name))
        surname: \(String(describing: surname))
        phone: \(String(describing: phone))
        address: \(String(describing: address))
        email: \(String(describing: email))
        type: \(String(describing: type))
        """
    }
    

}
