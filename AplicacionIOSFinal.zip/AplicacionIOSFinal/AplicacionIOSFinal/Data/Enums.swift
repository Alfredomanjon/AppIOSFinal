//
//  Enums.swift
//  AplicacionIOSFinal
//
//  Created by Alfredo Manjon on 09/05/2019.
//  Copyright © 2019 Alfredo Manjon. All rights reserved.
//

import UIKit

enum PassengerType: CustomStringConvertible {
    case bronce
    case plata
    case oro
    case diamante
    case platino
    
    // Use CustomStringConvertible and description
    
    var description: String {
        switch self {
            case .bronce:
                return typebronce.toLocalized()
            
            case .plata:
                return typeplata.toLocalized()
            
            case .oro:
                return NSLocalizedString("Oro", comment: "")
           
            case .diamante:
                return NSLocalizedString("Diamante", comment: "")
            
            case .platino:
                return NSLocalizedString("Platino", comment: "")
        }
    }
    
    var imagenes: String {
        
        switch self {
        
        case .bronce:
            return NSLocalizedString("bronce", comment: "")
        case .plata:
            return NSLocalizedString("plata", comment: "")
        case .oro:
            return NSLocalizedString("oro", comment: "")
        case .diamante:
            return NSLocalizedString("diamante", comment: "")
        case .platino:
            return NSLocalizedString("platino", comment: "")
            
        }
    }
    
    var colores : Int {
        
        switch self {
            
        case .bronce:
            return 0x786041
        case .plata:
            return 0xa6a6a6
        case .oro:
            return 0xfcc51e
        case .diamante:
            return 0x1f947d
        case .platino:
            return 0xd4cebe
            
        }
        
        
    }
}

enum genderPassengerType : CustomStringConvertible {
    case Man
    case Woman
    //arreglar
    var description: String {
        switch self {
        case .Man:
            return typebronce.toLocalized()
            
        case .Woman:
            return typeplata.toLocalized()
        }
    }
    
    var imagenes: String {
        switch self {
        case .Man:
            return NSLocalizedString("passenger_5", comment: "")
            
        case .Woman:
            return NSLocalizedString("passenger_6", comment: "")
        }
    }

}

enum TrainType: CustomStringConvertible {
    
    case Talgo
    case MediaDistancia
    case Avantia
    case Alvia
    case Ave
    
    var description: String {
        switch self {
        case .Talgo:
            return typeTalgo.toLocalized()
        case .MediaDistancia:
            return typeMediaDistancia.toLocalized()
        case .Avantia:
            return typeAvantia.toLocalized()
        case .Alvia:
            return typeAlvia.toLocalized()
        case .Ave:
            return typeAve.toLocalized()
            
        }
    }
    
    var imagenes: String {
        switch self {
        case .Talgo:
            return NSLocalizedString("TalgoTrain", comment: "")
        case .MediaDistancia:
            return NSLocalizedString("MDTrain", comment: "")
        case .Avantia:
            return NSLocalizedString("AvantiaTrain", comment: "")
        case .Alvia:
            return NSLocalizedString("AlviaTrain", comment: "")
        case .Ave:
           return NSLocalizedString("AveTrain", comment: "")
            
        }
    }
    
    var descripcion : String {
        switch  self{
        case .Talgo:
            return "Talgo, registrada actualmente como Patentes Talgo, es una empresa ferroviaria española creada en 1942 conocida principalmente por ser la creadora de los trenes Talgo, que además ofrece servicios de mantenimiento de trenes y relativos a equipos ferroviarios. Su nombre proviene del acrónimo 'Tren Articulado Ligero Goicoechea Oriol'"
        case .MediaDistancia:
            return "Renfe Media Distancia es la denominación comercial de los servicios de ámbito regional convencionales del operador ferroviario español Renfe Operadora. Por lo general, dichos servicios abarcan la conexión de distintas provincias de una misma Comunidad Autónoma o una contigua. Los trenes de Alta Velocidad que realizan servicios de media distancia reciben el nombre de Renfe Avant. Estos servicios circulan por casi la totalidad de la red ferroviaria española, incluidas las líneas de alta velocidad, circulando a una velocidad máxima de 250 km/h."
        case .Avantia:
            return "Renfe Avant es una marca comercial del operador español Renfe Operadora bajo la cual ofrece servicios de trenes de media distancia a alta velocidad, los cuales circulan a una velocidad que alcanza como máximo los 250 km/h — ligeramente inferior a la velocidad máxima de los AVE. Por lo general, estos servicios cubren distintas provincias dentro de una misma comunidad autónoma u otra contigua. Los servicios regionales a velocidad convencional reciben el nombre de Renfe Media Distancia"
        case .Alvia:
            return "Alvia es un servicio ferroviario de larga distancia del operador ferroviario español Renfe Operadora. Dicho servicio se caracteriza por recorrer trayectos que combinan tramos de alta velocidad con tramos a menor velocidad sobre vías de ancho ibérico. A diferencia de los trenes AVE, que no pueden circular por vías de ancho no adaptado a la alta velocidad, los trenes Alvia tienen un sistema de cambio de ancho por el cual pueden recorrer trayectos sobre ambos tipos de vía.El Alvia se diferencia del Altaria, otro servicio de Renfe, en que puede realizar el cambio de ancho sin necesidad de detenerse ni cambiar de locomotora en el proceso, lo que proporciona menores tiempos de viaje. Los servicios Alvia han ido sustituyendo progresivamente a los Altaria existentes allí donde ha sido posible.Una de las ventajas del Alvia es permitir que las ciudades que no disponen de alta velocidad se beneficien de una importante reducción en los tiempos de viaje. Los trenes Alvia circulan a una velocidad máxima de 250 km/h.en líneas de ancho internacional y a una velocidad máxima de 200 km/h en líneas ancho convencional. El servicio se realiza con trenes de las series 120, 130, 730, 121 y 252 con composiciones de Talgo 7."
        case .Ave:
            return "Renfe AVE (Alta Velocidad Española) es la marca comercial utilizada por la compañía ferroviaria española Renfe Operadora para sus trenes de alta velocidad de alta gama. Son trenes que circulan a una velocidad máxima de 310 km/h,1​ por líneas de ancho internacional (1435 mm) electrificadas a 25 kV y 50 Hz, en recorridos de larga distancia.En su inauguración en 1992, todos los trenes, sistemas y líneas dedicados a la alta velocidad en España eran denominados AVE. En la actualidad, las líneas son denominadas simplemente líneas de alta velocidad, y existen otros servicios de alta velocidad además del denominando AVE, como Alvia o Avant. En España, el uso del término AVE para todos los trenes de alta velocidad, tanto españoles como del extranjeros, se mantiene en el uso popular y ha sido reflejado en el Diccionario de la lengua española.El AVE es considerado el servicio insignia de Renfe Operadora. Dentro de toda la gama de servicios de alta velocidad ofrecida por Renfe (AVE, Avant, Alvia o Euromed), el AVE es el único capaz de alcanzar una velocidad comercial operativa de 310 km/h. Además, es el único servicio en el que Renfe ofrece restauración en el asiento, exceptuando Euromed.3"
       
        }
    }
}

enum TravelType: CustomStringConvertible {
    case Nacional
    case Europeo
    case Internacional
    case ExpressNacional
    
    // Use CustomStringConvertible and description
    
    var description: String {
        switch self {
        case .Nacional:
            return nacional.toLocalized()
            
        case .Europeo:
            return europeo.toLocalized()
            
        case .Internacional:
            return internacional.toLocalized()
            
        case .ExpressNacional:
            return expressNacional.toLocalized()
        }
    }
    
    var imagenes: String {
        switch self {
        case .Nacional:
            return NSLocalizedString("Barcelona", comment: "")
            
        case .Europeo:
            return NSLocalizedString("vienna", comment: "")
            
        case .Internacional:
            return NSLocalizedString("japon", comment: "")
            
        case .ExpressNacional:
            return NSLocalizedString("zaragoza", comment: "")
        }
    }
}
