//
//  TrainViewCell.swift
//  AplicacionIOSFinal
//
//  Created by Alfredo Manjon on 16/05/2019.
//  Copyright © 2019 Alfredo Manjon. All rights reserved.
//

import UIKit


class TrainViewCell : UITableViewCell {
    
    static let mIdentifier = String(describing : TrainViewCell.self)

    //MARK: -IBOUtlet-
    
    @IBOutlet weak var myView : UIView!
    @IBOutlet weak var myImage : UIImageView!
    @IBOutlet weak var seriesLabel : UILabel!
    @IBOutlet weak var capacityLabel : UILabel!
    @IBOutlet weak var typeLabel : UILabel!
    
    let defaultColor = CGFloat(0x781563)
    
    //MARK: -Function to update the cells-
    override func prepareForReuse() {
        
        myImage.image = nil
        seriesLabel.text = nil
        capacityLabel.text = nil
        typeLabel.text = nil
        
        
    }
    
    //MARK: - Public - make updates
    
    public func update(data train: Train?){
        
        update(image: train?.photo)
        update(series: train?.series)
        update(capacity: train?.capacity)
        update(type: train?.type)
        
        myView.layer.cornerRadius = 10
        myView.layer.borderWidth = 1
        myView.layer.borderColor = UIColor(rgb: 0xF8F8FF).cgColor
        myView.layer.shadowRadius = 4
        myView.layer.shadowColor = UIColor.gray.cgColor
        myView.layer.shadowOpacity = 0.6
        myView?.layer.shadowOffset = CGSize(width: 0, height: 3)
        
    }
    
    //MARK: - Private - Update Other elements
    
    private func update(image: String?){
        guard let imageData = image else {
            return
        }
        
        myImage.image = UIImage(named : imageData)
    }
    
    private func update(series : String?){
        seriesLabel.text = series
    }
    
    private func update(capacity : String?){
        capacityLabel.text = capacity
    }
    
    private func update(type : TrainType?){
        typeLabel.text = type?.description
    }
    
    
    
}

extension UIColor {
    convenience init(red: Int, green: Int, blue: Int) {
        assert(red >= 0 && red <= 255, "Invalid red component")
        assert(green >= 0 && green <= 255, "Invalid green component")
        assert(blue >= 0 && blue <= 255, "Invalid blue component")
        
        self.init(red: CGFloat(red) / 255.0, green: CGFloat(green) / 255.0, blue: CGFloat(blue) / 255.0, alpha: 1.0)
    }
    
    convenience init(rgb: Int) {
        self.init(
            red: (rgb >> 16) & 0xFF,
            green: (rgb >> 8) & 0xFF,
            blue: rgb & 0xFF
        )
    }
}

