//
//  DetailTrainViewCell.swift
//  AplicacionIOSFinal
//
//  Created by Alfredo Manjon on 25/05/2019.
//  Copyright © 2019 Alfredo Manjon. All rights reserved.
//

import UIKit

class DetailTrainViewCell : UITableViewCell {
    
    static let mIdentifier = String(describing : DetailTrainViewCell.self)
    
    //MARK: -IBOUtlet-
    
    @IBOutlet weak var mImage: UIImageView!
    @IBOutlet weak var mSeries : UILabel!
    @IBOutlet weak var mType : UILabel!
    @IBOutlet weak var mDescription : UITextView!
    
    //MARK: -Function to update the cells-
    override func prepareForReuse() {
        
        mImage.image = nil
        mSeries.text = nil
        mDescription.text = nil
        mType.text = nil
        
        
    }
    
    //MARK: - Public - make updates
    
    public func update(data train: Train?){
        
        update(image: train?.photo)
        update(series: train?.series)
        update(descripcion: train?.description)
        update(type: train?.type)
        
    }
    
    //MARK: - Private - Update Other elements
    
    private func update(image: String?){
        guard let imageData = image else {
            return
        }
        
        mImage.image = UIImage(named : imageData)
    }
    
    private func update(series : String?){
        mSeries.text = series
    }
    
    private func update(descripcion : String?){
        mDescription.text = descripcion
    }
    
    private func update(type : TrainType?){
        mType.text = type?.description
    }
    
    
    
    
    
}
