//
//  TrainDetailViewController.swift
//  AplicacionIOSFinal
//
//  Created by Alfredo Manjon on 20/05/2019.
//  Copyright © 2019 Alfredo Manjon. All rights reserved.
//

import UIKit

protocol TrainDetailDelegate {
    func onDelete(train: Train?)
}

class TrainDetailViewController: UIViewController {
    
    //MARK: -IBOutlets-
    
    @IBOutlet weak var myImageView: UIImageView!
    @IBOutlet weak var mySeriesLabel: UILabel!
    @IBOutlet weak var myTypeLabel: UILabel!
    @IBOutlet weak var myDescripcionLabel: UITextView!
    @IBOutlet weak var deleteButton: UIButton!
    
    @IBAction func onReturn(sender: UIBarButtonItem) {
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func onDeleteWhenPressend(sender: UIButton) {
        showAlert(title: NSLocalizedString("Delete a train", comment: ""),
                  message: NSLocalizedString("Are you sure do you want to delete this train?", comment: ""),
                  actionAccept: { _ in
                    self.returnPassenger()
        })
    }

    var delegate: TrainDetailDelegate?
    private var mData: Train? = nil
    
    func set(data train: Train){
        mData = train
    }
    
    // MARK: - Lifecycle -
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        configure(image: mData?.photo)
        configure(series: mData?.series)
        configure(type: mData?.type)
        configure(desc: mData?.descripcion)
        
        deleteButton.layer.backgroundColor = UIColor(rgb: 0xff0000).cgColor
        deleteButton.layer.cornerRadius = 10
    }
    
    deinit {
        
        delegate = nil
    }
    
    private func configure(image: String?) {
        guard let image = image else {
            return
        }
        myImageView?.image = UIImage(named: image)
    }
    
    private func configure(series: String?) {
        mySeriesLabel?.text = series
    }
    
    private func configure(type: TrainType?) {
        myTypeLabel?.text = type?.description
    }
    
    private func configure(desc: String?) {
        myDescripcionLabel?.text = desc
    }
    
    private func returnPassenger() {
        // Notify delegate to delete this element
        delegate?.onDelete(train: mData)
        
        dismiss(animated: true, completion: nil)
    }
    
}

extension UIViewController {
    func showAlert(title: String, message: String, actionAccept: ((UIAlertAction) -> Void)? = nil, actionCancel: ((UIAlertAction) -> Void)? = nil) {
        let alert = UIAlertController(title: title,
                                      message: message,
                                      preferredStyle: .alert)
        
        alert.addAction(UIAlertAction(title: NSLocalizedString("Accept", comment: ""),
                                      style: .default,
                                      handler: actionAccept))
        alert.addAction(UIAlertAction(title: NSLocalizedString("Cancel", comment: ""),
                                      style: .cancel,
                                      handler: actionCancel))
        
        self.present(alert, animated: true)
    }
}









