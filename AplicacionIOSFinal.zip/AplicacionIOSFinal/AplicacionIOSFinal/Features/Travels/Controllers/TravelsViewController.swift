//
//  TravelsViewController.swift
//  AplicacionIOSFinal
//
//  Created by Alfredo Manjon on 28/05/2019.
//  Copyright © 2019 Alfredo Manjon. All rights reserved.
//

import UIKit

class TravelsViewController : UIViewController {
    
    //MARK: -IBOutlets-
    
    @IBOutlet weak var mTableView : UITableView!
    
    // MARK: - Lifecycle -
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        configure(tableView: mTableView)
        
        mTableView.separatorStyle = UITableViewCell.SeparatorStyle.none
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        mTableView?.reloadData()
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle  == UITableViewCell.EditingStyle.delete{
            infoTrain.remove(at: indexPath.row)
            mTableView?.reloadData()
        }
    }
    
}

extension TravelsViewController {
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard let selectedCell = sender as? UITableViewCell,
            //Sacar posicion para saber que asignatura has elegido
            let position = mTableView.indexPath(for: selectedCell),
            let viewController = segue.destination as? TravelsDetailViewController else{
                return
        }
        let selectedTravel = infoTravel[position.row]
        viewController.delegate = self
        viewController.set(data : selectedTravel)
        
        
    }
    
}

extension TravelsViewController : UITableViewDataSource , UITableViewDelegate{
    private func configure(tableView: UITableView){
        mTableView.dataSource = self
        mTableView.delegate = self
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return infoTravel.count
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 170.0
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) ->
        UITableViewCell {
            
            //Para que se cambien el nombre de la clase automaticamente
            let cell = tableView.dequeueReusableCell(withIdentifier: TravelsViewCell.mIdentifier, for: indexPath)
            
            (cell as? TravelsViewCell)?.update(data: infoTravel[indexPath.row])
            
            return cell
    }
    
}

extension TravelsViewController: TravelsDetailDelegate {
    
    func onDelete(travel: Travels?) {
        guard let travelDelete = travel else {
            return
        }
        
        infoTravel.removeAll(where: { $0.destination == travelDelete.destination })
        mTableView.reloadData()
    }
}
