//
//  TravelsViewCell.swift
//  AplicacionIOSFinal
//
//  Created by Alfredo Manjon on 28/05/2019.
//  Copyright © 2019 Alfredo Manjon. All rights reserved.
//

import UIKit

class TravelsViewCell: UITableViewCell {

    static let mIdentifier = String(describing : TravelsViewCell.self)
    
    @IBOutlet weak var myView : UIView!
    @IBOutlet weak var titleView : UIView!
    @IBOutlet weak var destinationImage : UIImageView!
    @IBOutlet weak var departureLabel : UILabel!
    @IBOutlet weak var destinationLabel : UILabel!
    
    override func prepareForReuse() {
        
        destinationImage.image = nil
        departureLabel.text = nil
        destinationLabel.text = nil
    
    }
    
    public func update(data travel: Travels?){
        
        update(image: travel?.photoDestination)
        update(departure: travel?.departure)
        update(destination: travel?.destination)
      
        
    }
    
    private func update(image: String?){
        guard let imageData = image else {
            return
        }
        
        destinationImage.image = UIImage(named : imageData)
    }
    
    private func update(departure : String?){
        departureLabel.text = departure
    }
    
    private func update(destination : String?){
        destinationLabel.text = destination
    }
}

