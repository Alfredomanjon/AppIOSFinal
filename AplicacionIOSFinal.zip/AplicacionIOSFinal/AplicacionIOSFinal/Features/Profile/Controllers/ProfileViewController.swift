//
//  ProfileViewController.swift
//  AplicacionIOSFinal
//
//  Created by Alfredo Manjon on 03/06/2019.
//  Copyright © 2019 Alfredo Manjon. All rights reserved.
//

import UIKit

class  ProfileViewController : UIViewController {
    
    //MARK -IBOutlets
    
    @IBOutlet weak var generalView: UIView!
    @IBOutlet weak var myCardView: UIView!
    @IBOutlet weak var typeCard: UILabel!
    @IBOutlet weak var nameCard: UILabel!
    @IBOutlet weak var surnameCard: UILabel!
    @IBOutlet weak var nameTitle: UILabel!
    @IBOutlet weak var jobText: UILabel!
    @IBOutlet weak var mailText: UILabel!
    @IBOutlet weak var phoneText: UILabel!
    @IBOutlet weak var addressText: UILabel!
    @IBOutlet weak var memberTypeLabel: UILabel!
    @IBOutlet weak var travelsButton: UIButton!
    
    override func viewDidLoad() {
        update(data: infoProfile)
    }
    
    let profile : Profile? = nil
    
    func update( data profile: Profile?) {
        
        update(tipo: profile?.type?.description)
        update(nombreCard: profile?.name)
        update(apellidoCard: profile?.surname)
        update(nombre: profile?.name)
        update(trabajo: profile?.job)
        update(correo: profile?.mail)
        update(tlf: profile?.phone)
        update(dir: profile?.address)
        update(tipoTexto: profile?.type?.description)
        
        myCardView.layer.cornerRadius = 10
        myCardView.layer.backgroundColor = UIColor(rgb: profile?.type?.colores ?? 0x71232a).cgColor
        myCardView.layer.shadowRadius = 10
        myCardView.layer.shadowColor = UIColor.gray.cgColor
        myCardView.layer.shadowOpacity = 0.8
        myCardView.layer.shadowOffset = CGSize(width: 0, height: 3)
        travelsButton.layer.cornerRadius = 10
        
        
        
    }
    
    private func update(tipo: String?) {
        typeCard?.text = tipo
    }
    
    private func update(nombreCard: String?) {
        nameCard?.text = nombreCard
    }
    
    private func update(apellidoCard: String?) {
        surnameCard?.text = apellidoCard
    }
    
    private func update(nombre: String?) {
        nameTitle?.text = nombre
    }
    
    private func update(trabajo: String?) {
        jobText?.text = trabajo
    }
    
    private func update(correo: String?) {
        mailText?.text = correo
    }
    
    private func update(tlf: String?) {
        phoneText?.text = tlf
    }
    
    private func update(dir: String?) {
        addressText?.text = dir
    }
    
    private func update(tipoTexto: String?) {
        memberTypeLabel?.text = tipoTexto
    }
    
}
