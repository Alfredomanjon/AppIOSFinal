//
//  TravelsDitailViewController.swift
//  AplicacionIOSFinal
//
//  Created by Alfredo Manjon on 03/06/2019.
//  Copyright © 2019 Alfredo Manjon. All rights reserved.
//

import UIKit

protocol TravelsDetailDelegate {
    func onDelete(travel: Travels?)
}

class TravelsDetailViewController : UIViewController {
    
    //MARK: -IBActions-
    
    @IBAction func onReturn(sender: UIBarButtonItem) {
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func onDeleteWhenPressend(sender: UIButton) {
        showAlert(title: NSLocalizedString("Delete a travel", comment: ""),
                  message: NSLocalizedString("Are you sure do you want to delete this travel?", comment: ""),
                  actionAccept: { _ in
                    self.returnTravel()
        })
    }
    
    //MARK: -IBOutlets-
    
    @IBOutlet weak var myImageView: UIImageView!
    @IBOutlet weak var myDepartureView: UIView!
    @IBOutlet weak var myDeparture: UILabel!
    @IBOutlet weak var myArrivalView: UIView!
    @IBOutlet weak var myArrival: UILabel!
    @IBOutlet weak var myKm: UILabel!
    @IBOutlet weak var myTravelType: UITextView!
    @IBOutlet weak var deleteButton: UIButton!
    
    
    var delegate: TravelsDetailDelegate?
    private var mData: Travels? = nil
    
    
    func set(data travel: Travels){
        mData = travel
    }
    
    // MARK: - Lifecycle -
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        configure(image: mData?.photoDestination)
        configure(departure: mData?.departure)
        configure(arrival: mData?.destination)
        configure(km: mData?.km)
        configure(type: mData?.train?.description)
        
        myArrivalView.layer.cornerRadius = 10
        myDepartureView.layer.cornerRadius = 10
        
        deleteButton.layer.backgroundColor = UIColor(rgb: 0xff0000).cgColor
        deleteButton.layer.cornerRadius = 10
    }
    
    private func configure(image: String?) {
        guard let image = image else {
            return
        }
        myImageView?.image = UIImage(named: image)
    }
    
    private func configure(departure: String?) {
        myDeparture?.text = departure
    }
    
    private func configure(arrival: String?) {
        myArrival?.text = arrival
    }
    
    private func configure(km: String?) {
        myKm?.text = km
    }
    
    private func configure(type: String?) {
        myTravelType?.text = type
    }
    
    private func returnTravel() {
        // Notify delegate to delete this element
        delegate?.onDelete(travel: mData)
        
        dismiss(animated: true, completion: nil)
    }
}

extension UIViewController {
    func showAlertIgnore(title: String, message: String, actionAccept: ((UIAlertAction) -> Void)? = nil, actionCancel: ((UIAlertAction) -> Void)? = nil) {
        let alert = UIAlertController(title: title,
                                      message: message,
                                      preferredStyle: .alert)
        
        alert.addAction(UIAlertAction(title: NSLocalizedString("Accept", comment: ""),
                                      style: .default,
                                      handler: actionAccept))
        alert.addAction(UIAlertAction(title: NSLocalizedString("Cancel", comment: ""),
                                      style: .cancel,
                                      handler: actionCancel))
        
        self.present(alert, animated: true)
    }
}
