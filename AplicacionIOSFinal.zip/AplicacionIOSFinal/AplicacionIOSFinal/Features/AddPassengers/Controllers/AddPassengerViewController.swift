//
//  AddPassengerViewController.swift
//  AplicacionIOSFinal
//
//  Created by Alfredo Manjon on 14/05/201
//  Copyright © 2019 Alfredo Manjon. All rights reserved.
//

import UIKit

class AddPassengerViewController: UIViewController {
    
    //MARK -IBActions-
    @IBAction func cancelar(sender: UIBarButtonItem) {
        dismiss(animated: true, completion: nil)
    }
    
    // MARK: -IBOUtlets-
    @IBOutlet weak var nameText: UITextField!
    @IBOutlet weak var surnameText: UITextField!
    @IBOutlet weak var addresText: UITextField!
    @IBOutlet weak var phoneText: UITextField!
    @IBOutlet weak var emailText: UITextField!
    @IBOutlet weak var typeStruct: UISegmentedControl!
    @IBOutlet weak var genderStruct: UISegmentedControl!
    
    @IBAction func add(_ sender: Any) {
        
        addPassenger()
        dismiss(animated: true, completion: nil)
        
    }
    
    func chooseGenderOpcion() -> genderPassengerType{
        
        if (genderStruct.selectedSegmentIndex == 0) {
            return genderPassengerType.Man
        }
        else if(genderStruct.selectedSegmentIndex == 1){
            return genderPassengerType.Woman
        }
        
        return genderPassengerType.Woman
    
    }
    
    func choosetypeOpcion() -> PassengerType{
        
        if (typeStruct.selectedSegmentIndex == 0) {
            return PassengerType.bronce
        }
        else if(typeStruct.selectedSegmentIndex == 2){
            return PassengerType.plata
        }
        else if(typeStruct.selectedSegmentIndex == 2){
            return PassengerType.oro
        }
        else if(typeStruct.selectedSegmentIndex == 2){
            return PassengerType.diamante
        }
        else if(typeStruct.selectedSegmentIndex == 2){
            return PassengerType.platino
        }
        
        return PassengerType.bronce
        
    }

    
    func addPassenger(){
        
       infoPassenger.append(Passenger.init(photo: chooseGenderOpcion().imagenes,
                                           name: nameText.text,
                                           surname: surnameText.text,
                                           phone: phoneText.text,
                                           address: addresText.text,
                                           email: emailText.text,
                                           type: choosetypeOpcion(),
                                           photoType: choosetypeOpcion().imagenes))
        
    }
    
    
    
    
}


