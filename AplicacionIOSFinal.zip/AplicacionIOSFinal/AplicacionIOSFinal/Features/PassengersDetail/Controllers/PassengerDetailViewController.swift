//
//  PassengerDetailViewController.swift
//  AplicacionIOSFinal
//
//  Created by Alfredo Manjon on 01/06/2019.
//  Copyright © 2019 Alfredo Manjon. All rights reserved.
//

import UIKit

protocol PassengerDetailDelegate {
    func onDelete(passenger: Passenger?)
}

class  PassengerDetailViewController:  UIViewController {
    
    //MARK: -IBOulets-
    @IBOutlet weak var generalView: UIView!
    @IBOutlet weak var leagueView: UIView!
    @IBOutlet weak var DetailView: UIView!
    @IBOutlet weak var myImageView: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var surnameLabel: UILabel!
    @IBOutlet weak var addresLabel: UILabel!
    @IBOutlet weak var phoneLabel: UILabel!
    @IBOutlet weak var emailLabel: UILabel!
    @IBOutlet weak var typeLabel: UILabel!
    @IBOutlet weak var deleteButton: UIButton!

    //MARK: -IBActions-
    @IBAction func onReturn(sender: UIBarButtonItem) {
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func onDeleteWhenPressend(sender: UIButton) {
        showAlert(title: NSLocalizedString("Delete a passenger", comment: ""),
                  message: NSLocalizedString("Are you sure do you want to delete this passenger?", comment: ""),
                  actionAccept: { _ in
                    self.returnPassenger()
        })
    }
    
    private var mData: Passenger? = nil
    var delegate: PassengerDetailDelegate?
    
    func set(data passenger: Passenger){
        mData = passenger
    }
    
    // MARK: - Lifecycle -
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        configure(image: mData?.photo)
        configure(name: mData?.name)
        configure(surname: mData?.surname)
        configure(addres: mData?.address)
        configure(phone: mData?.phone)
        configure(email: mData?.email)
        configure(type: mData?.type?.description)
        leagueView.layer.cornerRadius = 10
        leagueView.layer.backgroundColor = UIColor(rgb: mData?.type?.colores ?? 0x71232a).cgColor
        deleteButton.layer.backgroundColor = UIColor(rgb: 0xff0000).cgColor
        deleteButton.layer.cornerRadius = 10
        
    }
    
    private func configure(image: String?) {
        guard let image = image else {
            return
        }
        myImageView?.image = UIImage(named: image)
    }
    
    private func configure(name: String?) {
        nameLabel?.text = name
    }
    
    private func configure(surname: String?) {
        surnameLabel?.text = surname
    }
    
    private func configure(addres: String?) {
        addresLabel?.text = addres
    }
    
    private func configure(phone: String?) {
        phoneLabel?.text = phone
    }
    
    private func configure(email: String?) {
        emailLabel?.text = email
    }
    
    private func configure(type: String?) {
        emailLabel?.text = type
    }
    
    private func returnPassenger() {
        // Notify delegate to delete this element
        delegate?.onDelete(passenger: mData)
        
        dismiss(animated: true, completion: nil)
    }

}

extension UIViewController {
    func showAlert1(title: String, message: String, actionAccept: ((UIAlertAction) -> Void)? = nil, actionCancel: ((UIAlertAction) -> Void)? = nil) {
        let alert = UIAlertController(title: title,
                                      message: message,
                                      preferredStyle: .alert)
        
        alert.addAction(UIAlertAction(title: NSLocalizedString("Accept", comment: ""),
                                      style: .default,
                                      handler: actionAccept))
        alert.addAction(UIAlertAction(title: NSLocalizedString("Cancel", comment: ""),
                                      style: .cancel,
                                      handler: actionCancel))
        
        self.present(alert, animated: true)
    }
}
