//
//  ProfileDetailViewController.swift
//  AplicacionIOSFinal
//
//  Created by Alfredo Manjon on 05/06/2019.
//  Copyright © 2019 Alfredo Manjon. All rights reserved.
//

import UIKit

class ProfileDetailViewController : UIViewController{
    
    //MARK -IBAction-
    @IBAction func onReturn(sender: UIBarButtonItem) {
        dismiss(animated: true, completion: nil)
    }
    
    @IBOutlet weak var mTableView : UITableView!
    
    // MARK: - Lifecycle -
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        configure(tableView: mTableView)
        
        UINavigationBar.appearance().shadowImage = UIImage()
        
        mTableView.separatorStyle = UITableViewCell.SeparatorStyle.none
        
    }
    
}


extension ProfileDetailViewController : UITableViewDataSource , UITableViewDelegate{
    private func configure(tableView: UITableView){
        mTableView.dataSource = self
        mTableView.delegate = self
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return profileTravels.count
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 170.0
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) ->
        UITableViewCell {
            
            //Para que se cambien el nombre de la clase automaticamente
            let cell = tableView.dequeueReusableCell(withIdentifier: ProfileDetailViewCell.mIdentifier, for: indexPath)
            
            (cell as? ProfileDetailViewCell)?.update(data: profileTravels[indexPath.row])
            
            return cell
    }
   
}
