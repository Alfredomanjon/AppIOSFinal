//
//  ProfileDetail.swift
//  AplicacionIOSFinal
//
//  Created by Alfredo Manjon on 05/06/2019.
//  Copyright © 2019 Alfredo Manjon. All rights reserved.
//

import UIKit

class ProfileDetailViewCell : UITableViewCell {
    
    static let mIdentifier = String(describing : ProfileDetailViewCell.self)
    
    //MARK -IBOtlets-
    @IBOutlet weak var myView : UIView!
    @IBOutlet weak var titleView : UIView!
    @IBOutlet weak var destinationImage : UIImageView!
    @IBOutlet weak var departureLabel : UILabel!
    @IBOutlet weak var destinationLabel : UILabel!
    
    override func prepareForReuse() {
        
        destinationImage.image = nil
        departureLabel.text = nil
        destinationLabel.text = nil
        
    }
    
    public func update(data travel: Travels?){
        
        update(image: travel?.photoDestination)
        update(departure: travel?.departure)
        update(destination: travel?.destination)
        
        myView.layer.cornerRadius = 10
        myView.layer.shadowRadius = 3
        myView.layer.shadowColor = UIColor.gray.cgColor
        myView.layer.shadowOpacity = 0.8
        myView.layer.shadowOffset = CGSize(width: 0, height: 3)
        destinationImage.layer.cornerRadius = 10
        titleView.layer.cornerRadius = 10
        
        
    }
    
    private func update(image: String?){
        guard let imageData = image else {
            return
        }
        
        destinationImage.image = UIImage(named : imageData)
    }
    
    private func update(departure : String?){
        departureLabel.text = departure
    }
    
    private func update(destination : String?){
        destinationLabel.text = destination
    }
    
    
}
