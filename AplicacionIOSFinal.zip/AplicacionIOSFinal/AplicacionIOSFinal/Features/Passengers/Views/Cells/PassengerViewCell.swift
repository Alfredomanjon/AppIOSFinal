//
//  PassengerViewCell.swift
//  AplicacionIOSFinal
//
//  Created by Alfredo Manjon on 09/05/2019.
//  Copyright © 2019 Alfredo Manjon. All rights reserved.
//

import UIKit

class PassengerViewCell : UICollectionViewCell {
    
    static let mIdentifier = String(describing : PassengerViewCell.self)
    
    //MARK: - IBOutlets
    @IBOutlet weak var myView : UIView!
    @IBOutlet weak var textView : UIView!
    @IBOutlet weak var myImage : UIImageView!
    @IBOutlet weak var nameLabel : UILabel!
    @IBOutlet weak var surnameLabel : UILabel!

    
    //Function to update the cells
    override func prepareForReuse() {
        
        myImage.image = nil
        nameLabel.text = nil
        surnameLabel.text = nil
        
    
    }
    
    //MARK: - Public -
    
    public func update(data passenger: Passenger?){
        
        update(image: passenger?.photo)
        update(name: passenger?.name)
        update(email: passenger?.surname)
        
        textView.layer.cornerRadius = 10
        textView.layer.borderWidth = 1
        textView.layer.borderColor = UIColor(rgb: 0x781562).cgColor
        textView.layer.shadowRadius = 4
        textView.layer.shadowColor = UIColor.gray.cgColor
        textView.layer.shadowOpacity = 0.6
        textView?.layer.shadowOffset = CGSize(width: 0, height: 3)
    
    }
    
    //MARK: - Private -
    
    private func update(image: String?){
        guard let imageData = image else {
            return
        }
        
        myImage.image = UIImage(named : imageData)
    }
    
    private func update(name : String?){
        nameLabel.text = name
    }
    
    private func update(email : String?){
        surnameLabel.text = email
    }

}
