//
//  PassengerViewContoller.swift
//  AplicacionIOSFinal
//
//  Created by Alfredo Manjon on 09/05/2019.
//  Copyright © 2019 Alfredo Manjon. All rights reserved.
//


import UIKit

class PassengerViewController: UIViewController {
    // MARK: - IBOutlets -
    @IBOutlet weak var mCollectionView: UICollectionView!
    
    // MARK: - IBOutlets -
    @IBAction func Borrrar(sender: UIButton) {
        func CollectionView(_ tableView: UITableView,forRowAt indexPath: IndexPath){
            infoPassenger.remove(at: indexPath.row)
            mCollectionView?.reloadData()
        }
    }
    
    // MARK: - Properties -
    private let mCellSpacing: CGFloat = 10.0
    
    
    // MARK: - Lifecycle -
    override func viewDidLoad() {
        super.viewDidLoad()

        configureTableView()
        
        mCollectionView.reloadData()
        
     
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        mCollectionView?.reloadData()
    }
    
    
    // MARK: - Configuration -
    private func configureTableView() {
        // Set self view controller as delegate and data source of collectionView
        mCollectionView.delegate = self
        mCollectionView.dataSource = self
    }
    
    func tableView(_ tableView: UICollectionView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle  == UITableViewCell.EditingStyle.delete{
            infoPassenger.remove(at: indexPath.row)
            mCollectionView?.reloadData()
        }
    }
    
}
//Detail extension
extension PassengerViewController {
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard let selectedCell = sender as? UICollectionViewCell,
            let position = mCollectionView.indexPath(for: selectedCell),
            let viewController = segue.destination as? PassengerDetailViewController else{
                return
        }
        let selectedSubject = infoPassenger[position.row]
        viewController.delegate = self
        viewController.set(data : selectedSubject)
        
        
    }
    
}

// SubjectsViewController to implement UICollectionView delegate and data source
extension PassengerViewController: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    // UICollectionViewDataSource
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return infoPassenger.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: PassengerViewCell.mIdentifier,
                                                      for: indexPath) as! PassengerViewCell
        // Get student data for row
        let passenger = infoPassenger[indexPath.row]
            // Configure cell view with student data
        cell.update(data: passenger)
        
        return cell
    }
    
    // UICollectionViewDelegateFlowLayout
    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        let size = collectionView.frame.size.width / 2
        return CGSize(width: size - mCellSpacing,
                      height: size - mCellSpacing)
    }
    
    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        minimumInteritemSpacingForSectionAt section: Int,
                        minimunExternitemSpacingForSectionAt section2: Int) -> CGFloat {
        return mCellSpacing
    }
    
    func collectionView(_ collectionView: UICollectionView, layout
        collectionViewLayout: UICollectionViewLayout,
                        minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return mCellSpacing
    }
    
}

extension PassengerViewController: PassengerDetailDelegate {
    func onDelete(passenger: Passenger?) {
        guard let passengerDelete = passenger else {
            return
        }
        
        infoPassenger.removeAll(where: { $0.name == passengerDelete.name })
        mCollectionView.reloadData()
    }
}



