//
//  AddTrainViewController.swift
//  AplicacionIOSFinal
//
//  Created by Alfredo Manjon on 19/05/2019.
//  Copyright © 2019 Alfredo Manjon. All rights reserved.
//

import UIKit

class AddTrainViewController: UIViewController{
    
    let sendValue = TrainViewController();
    
    
    @IBAction func cancelar(sender: UIBarButtonItem) {
        dismiss(animated: true, completion: nil)
    }
    
    @IBOutlet weak var seriesText: UITextField!
    @IBOutlet weak var capacityText: UITextField!
    @IBOutlet weak var typeStruct: UISegmentedControl!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        UINavigationBar.appearance().shadowImage = UIImage()
    
    }
    
    @IBAction func add(_ sender: Any) {
        
        addTrain()
        dismiss(animated: true, completion: nil)
        
    }
 
    func chooseOpcion() -> TrainType{
        
        if (typeStruct.selectedSegmentIndex == 0) {
            return TrainType.Alvia
        }
        else if(typeStruct.selectedSegmentIndex == 1){
            return TrainType.Ave
        }
        else if(typeStruct.selectedSegmentIndex == 2){
            return TrainType.MediaDistancia
        }
        else if(typeStruct.selectedSegmentIndex == 3){
            return TrainType.Talgo
        }
       
        return .Alvia
        
        
    }
 
    
    func addTrain(){
        
        infoTrain.append(Train.init(photo: chooseOpcion().imagenes,
                                    series: seriesText.text,
                                    capacity: capacityText.text,
                                    type: chooseOpcion(),
                                    descripcion: chooseOpcion().descripcion))
        
    }
    
}
