//
//  AddTravelsViewController.swift
//  AplicacionIOSFinal
//
//  Created by Alfredo Manjon on 02/06/2019.
//  Copyright © 2019 Alfredo Manjon. All rights reserved.
//

import UIKit

class AddTravelsViewController : UIViewController {
    
    //MARK -IBActions-
    @IBAction func cancelar(sender: UIBarButtonItem) {
        dismiss(animated: true, completion: nil)
    }
    
    //MARK: -IBOutlet-
    @IBOutlet weak var departureText: UITextField!
    @IBOutlet weak var destinationText: UITextField!
    @IBOutlet weak var kmText: UITextField!
    @IBOutlet weak var typeStruct: UISegmentedControl!
    
    @IBAction func add(_ sender: Any) {
        
        addTravel()
        dismiss(animated: true, completion: nil)
        
    }
    
    func chooseOpcion() -> TravelType{
        
        if (typeStruct.selectedSegmentIndex == 0) {
            return TravelType.Nacional
        }
        else if(typeStruct.selectedSegmentIndex == 1){
            return TravelType.Europeo
        }
        else if(typeStruct.selectedSegmentIndex == 2){
            return TravelType.Internacional
        }
        else if(typeStruct.selectedSegmentIndex == 3){
            return TravelType.ExpressNacional
        }
        
        return TravelType.Nacional
    }
    
    func addTravel(){
        
        infoTravel.append(Travels.init(photoDestination: chooseOpcion().imagenes,
                                       destination: destinationText.text,
                                       departure: departureText.text,
                                       type: chooseOpcion(),
                                       km: kmText.text,
                                       train: infoTrain.filter{$0.series == "982"},
                                       passengers: infoPassenger.filter{$0.name?.contains("e") ?? false}))
        
    }
}
