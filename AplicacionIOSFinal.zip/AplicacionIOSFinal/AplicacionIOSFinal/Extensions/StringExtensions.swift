//
//  StringExtensions.swift
//  AplicacionIOSFinal
//
//  Created by Alfredo Manjon on 12/05/2019.
//  Copyright © 2019 Alfredo Manjon. All rights reserved.
//

import Foundation

extension String {
    
    func toLocalized() -> String {
        
        return NSLocalizedString(self, comment: "")
        
    }
    
}

let typebronce = "bronce1";
let typeplata = "plata";
let oro = "oro";
let diamante = "diamante";
let platino = "platino";


let typeTalgo = "Talgo";
let typeMediaDistancia = "MediaDistancia";
let typeAvantia = "Avantia";
let typeAlvia = "Alvia";
let typeAve = "Ave";

let nacional = "Nacional1";
let europeo = "Europeo1";
let internacional = "Internacional1";
let expressNacional = "ExpressNacional1";

